
<script>

export default {
 props:{ datosUsuario: Array
    },
	data() {
		return {

        }
        },
        components: {
        }
        
}
</script>